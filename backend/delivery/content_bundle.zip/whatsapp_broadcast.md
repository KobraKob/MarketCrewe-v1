<think>
We are creating WhatsApp broadcast messages for Dr. Squatch, a soap brand targeting men.
 The messages must be text-only, 2-3 lines max, with a humorous tone, urgency-driven, and include a CTA.
 Products: soap
 Goals: reach and growth, so we want to encourage sharing or trying new products.
 Audience: male

 Important: Only output the two messages, no additional text.

 Let's brainstorm two options:

 Option 1:
 - Start with a humorous line about soap being manly or avoiding smelling bad.
 - Create urgency: limited time, stock running out, etc.
 - CTA: Encourage to try or buy now.

 Option 2:
 - Another humorous angle: maybe about being the hero of your shower, or not using your partner's flowery soap.
 - Urgency: perhaps a special offer ending soon.
 - CTA: Click a link or share with friends.

 We must keep it very short (2-3 lines) and friendly.

 Example structure:
 Line 1: Hook (funny)
 Line 2: Urgency + CTA

 Let's create:

 Option 1:
 "Tired of smelling like a locker room? 🏈 Our manly soaps are here to rescue! 
  Don't wait – limited stock. Grab yours now: [Link]"

 But we can make it more humorous and urgent.

 Revised Option 1:
 "Dude, your soap shouldn't smell like flowers. Get rugged with Dr. Squatch! 
  Last chance for this week's bricklayer scent – running out fast! Grab it: [Link]"

 Option 2:
 "Warning: Your shower is a danger zone without Dr. Squatch. 
  This week only: 20% off the Pine Tar warrior kit. Be a hero. Shop now: [Link]"

 But we have to avoid specific discounts if not provided? The prompt says "this week's content or products", so we can be general.

 Alternatively, without discount:

 Option 2:
 "Stop the shower shame! Upgrade to soap that doesn't disappoint. 
  Fresh batch just dropped – get it before it's gone! [Link]"

 However, let's make sure they are humorous and urgency-driven.

 Final two options:

 1. 
 "Hey! Still using that girly soap? 😂 Man up with Dr. Squatch! 
  This week's batch is flying off shelves. Don't miss out! Grab yours: [Link]"

 2.
 "Is your soap weak? Time to get a bar that can handle your grit. 
  Limited stock of our best-sellers – act fast! Upgrade now: [Link]"

 But let's make sure they are 2-3 lines and within the limit.

 We'll go with:

 1.
 "Ditch the weak soap, bro! Dr. Squatch bars are built tough for real men. 
  Our new Cedar Citrus is almost gone. Grab it before it's history! [Link]"

 2.
 "Tired of smelling like your grandma's garden? 🌸 Get manly scents from Dr. Squatch! 
  Limited time offer – stock up now before we run dry! Shop: [Link]"

 These are 2 lines each, humorous, urgency-driven, and have a CTA.

 But note: the product is soap, and we are promoting this week's content or products. We can mention a specific product (like Cedar Citrus) or keep it general. Since we don't have a specific product this week, we can use a placeholder or a general reference.

 Since the prompt doesn't specify a particular product, we can use:

 Option 1: Mention a popular scent that might be in high demand.
 Option 2: Keep it general but with a humorous twist.

 Let's finalize:

 1. "Bro, your shower game is weak. Level up with Dr. Squatch's manly suds! 
     This week's Pine Tar is flying off shelves. Grab a bar before it's gone! [Link]"

 2. "Stop the shower shame! Get soap that doesn't smell like flowers. 
     Fresh batch of our best-sellers is here but going fast. Man up now: [Link]"

 These are two options that fit the criteria.

 However, note: the first option mentions "Pine Tar" and the second is more general. Both are acceptable.

 Now, output only the two messages as per the format:

 1. Bro, your shower game is weak. Level up with Dr. Squatch's manly suds! This week's Pine Tar is flying off shelves. Grab a bar before it's gone! [Link]
 2. Stop the shower shame! Get soap that doesn't smell like flowers. Fresh batch of our best-sellers is here but going fast. Man up now: [Link]

 But wait, we must ensure they are 2-3 lines. In WhatsApp, we can break them into two lines each.

 Let's format as:

 1. 
 Bro, your shower game is weak. Level up with Dr. Squatch's manly suds! 
 This week's Pine Tar is flying off shelves. Grab a bar before it's gone! [Link]

 2.
 Stop the shower shame! Get soap that doesn't smell like flowers. 
 Fresh batch of our best-sellers is here but going fast. Man up now: [Link]

 This is two lines each.

 Now, we output exactly as:

1. Bro, your shower game is weak. Level up with Dr. Squatch's manly suds! 
This week's Pine Tar is flying off shelves. Grab a bar before it's gone! [Link]

2. Stop the shower shame! Get soap that doesn't smell like flowers. 
Fresh batch of our best-sellers is here but going fast. Man up now: [Link]
</think>
1. Bro, your shower game is weak. Level up with Dr. Squatch’s manly suds!  
Pine Tar bars flying off shelves—grab yours before it’s gone! [Link]  

2. Tired of smelling like a garden? 🌸 Get rugged suds that don’t quit!  
Limited stock of Cedar Citrus—snag a bar & smell legendary now. [Link]