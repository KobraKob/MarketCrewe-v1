<think>
We are creating ad copy for Dr. Squatch soap products targeting males with a humorous tone.
 The goal is reach and growth, so we want engaging and shareable content.
 Products: Since only "soap" is specified, we'll assume 3 popular Dr. Squatch soap scents for variety.
 Let's choose:
 1. Pine Tar
 2. Bay Rum
 3. Cool Fresh Aloe

 For each product, we need:
 - 2 Ad Headlines (max 40 characters)
 - 1 Short Ad Description (max 90 characters)
 - 1 Call to Action (CTA)

 Remember: Tone is humorous and target audience is male.

 Let's brainstorm:

 Product 1: Pine Tar
 Headline ideas:
  - "Smell Like a Lumberjack's Dream" (32 chars)
  - "Tough Grime? Pine Power!" (24 chars)
 Description: A humorous take on its tough cleaning and manly scent.
  - "Our pine-packed bar tackles dirt like a bear tackling... well, anything. Get rugged clean!" (84 chars)
 CTA: "Get Soapin'"

 Product 2: Bay Rum
 Headline ideas:
  - "Pirate-Approved Suds Ahoy!" (27 chars)
  - "Rum Scent? No Hangover!" (23 chars)
 Description: Play on pirate theme and rum scent without the alcohol.
  - "Sail through stench with this spicy, pirate-worthy brew. Bath time just got adventurous!" (83 chars)
 CTA: "Set Sail for Suds"

 Product 3: Cool Fresh Aloe
 Headline ideas:
  - "Chill Out, It's Soap Time!" (26 chars)
  - "Hot Skin? Cool Aloe Cure" (25 chars)
 Description: Focus on cooling and refreshing.
  - "Like a cool breeze for your pits. Aloe vera soothes while it scrubs. Stay fresh, dude!" (83 chars)
 CTA: "Chill & Lather"

 Now, let's format as per the instructions in Markdown.
</think>
### Pine Tar Soap
**Ad Headlines**  
- Smell Like a Lumberjack's Dream  
- Tough Grime? Pine Power!  

**Short Ad Description**  
Our pine-packed bar tackles dirt like a bear tackling... well, anything. Get rugged clean!  

**CTA**  
Get Soapin'  

---  

### Bay Rum Soap  
**Ad Headlines**  
- Pirate-Approved Suds Ahoy!  
- Rum Scent? No Hangover!  

**Short Ad Description**  
Sail through stench with this spicy, pirate-worthy brew. Bath time just got adventurous.  

**CTA**  
Set Sail for Suds  

---  

### Cool Fresh Aloe Soap  
**Ad Headlines**  
- Chill Out, It's Soap Time!  
- Hot Skin? Cool Aloe Cure  

**Short Ad Description**  
Like a cool breeze for your pits. Aloe vera soothes while it scrubs. Stay fresh, dude.  

**CTA**  
Chill & Lather  

---  

### Cedar Citrus Soap  
**Ad Headlines**  
- Citrus Zing, Manly Clean!  
- Smell Like a Campfire MVP  

**Short Ad Description**  
Wake up your nose with zesty citrus and woodsy cedar. Because "meh" scents are for dish soap.  

**CTA**  
Zap the Funk  

---  

### Eucalyptus Greek Yogurt Soap  
**Ad Headlines**  
- Greek Yogurt? On Your Bod!  
- Eucalyptus Punch for Stink  

**Short Ad Description**  
Spoil your skin with creamy yogurt and minty eucalyptus. Shower like a Greek god (minus the toga).  

**CTA**  
Sudsy Upgrade Now  